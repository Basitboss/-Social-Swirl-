// Example: console log when the page loads
document.addEventListener("DOMContentLoaded", () => {
    console.log("Success page loaded.");
  });

  

  

document.querySelectorAll('.category-btn').forEach(button => {
  button.addEventListener('click', () => {
    alert(`Loading jobs for: ${button.textContent}`);
  });
});



// Show modal
document.querySelector('.cta-btn').addEventListener('click', () => {
  document.getElementById('signinModal').style.display = 'flex';
});

// Hide modal
document.getElementById('closeModal').addEventListener('click', () => {
  document.getElementById('signinModal').style.display = 'none';
});

// Optional: Close when clicking outside modal
window.addEventListener('click', (e) => {
  const modal = document.getElementById('signinModal');
  if (e.target === modal) {
    modal.style.display = 'none';
  }
});

// Wait for the DOM to load
document.addEventListener("DOMContentLoaded", function () {
  const applyButtons = document.querySelectorAll(".apply-btn");
  const modal = document.getElementById("applyModal");
  const closeBtn = document.getElementById("closeApplyModal");
  const jobTitle = document.getElementById("jobTitle");

  applyButtons.forEach(button => {
    button.addEventListener("click", () => {
      const jobName = button.getAttribute("data-job");
      jobTitle.textContent = `Apply for ${jobName}`;
      modal.style.display = "block";
    });
  });

  closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
  });

  window.addEventListener("click", (event) => {
    if (event.target === modal) {
      modal.style.display = "none";
    }
  });
});

    // Optional: Add a click animation or log to the "Plans" buttons
    document.querySelectorAll(".plan-btn").forEach(button => {
        button.addEventListener("click", () => {
          alert("You clicked on a plan! More features can be added here.");
        });
      });
      
      
      document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('click', () => {
          alert('Thank you for choosing Growvy!');
        });
      });
      
      
      
      document.querySelector('.cta-btn').addEventListener('click', () => {
        alert('Redirecting to scheduling page...');
      });
      
      
    //   <!-- Optional JavaScript for interactivity -->

    // Example JS: Highlight current page
    const links = document.querySelectorAll('nav a');
    links.forEach(link => {
      if (link.textContent.trim() === 'Pricing') {
        link.style.textDecoration = 'underline';
      }
    });


  // Highlight the current plan type on scroll (can expand with IntersectionObserver later)
  document.querySelectorAll('.plans-btn').forEach(button => {
    button.addEventListener('click', () => {
      alert("Redirecting to full plan details...");
    });
  });
